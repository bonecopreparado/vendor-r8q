/* Inspect the serialized policy using the SAME pinned libsepol as secilc.
 * No policy load, no device access, no changes to the supplied policy file. */
#include <stdio.h>
#include <stdlib.h>
#include <sepol/policydb.h>
#include <sepol/policydb/policydb.h>
#include <sepol/policydb/polcaps.h>
#include <sepol/policydb/ebitmap.h>

int main(int argc, char **argv) {
    sepol_policydb_t *db = NULL;
    sepol_policy_file_t *file = NULL;
    FILE *fp;
    int status = 1;
    if (argc < 3) { fprintf(stderr, "usage: check-policy-caps POLICY CAP...\n"); return 2; }
    fp = fopen(argv[1], "rb");
    if (!fp) { perror("fopen"); return 2; }
    if (sepol_policydb_create(&db) || sepol_policy_file_create(&file)) goto done;
    sepol_policy_file_set_fp(file, fp);
    if (sepol_policydb_read(db, file)) goto done;
    printf("policy_version=%u\n", db->p.policyvers);
    if (db->p.policyvers != 30) goto done;
    status = 0;
    for (int i = 2; i < argc; ++i) {
        int number = sepol_polcap_getnum(argv[i]);
        int enabled = number >= 0 && ebitmap_get_bit(&db->p.policycaps, (unsigned int)number);
        printf("policycap %s index=%d enabled=%d\n", argv[i], number, enabled);
        if (!enabled) status = 1;
    }
done:
    sepol_policy_file_free(file);
    sepol_policydb_free(db);
    fclose(fp);
    return status;
}
