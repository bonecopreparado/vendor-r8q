"""Compile exact CIL inputs without dropping capabilities. Offline only."""
from pathlib import Path
import argparse
import hashlib
import json
import re
import struct
import subprocess

ROOT = Path(__file__).resolve().parent
SHA = lambda data: hashlib.sha256(data).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--secilc', required=True, type=Path)
    parser.add_argument('--cap-checker', required=True, type=Path)
    parser.add_argument('--out', required=True, type=Path)
    parser.add_argument('--genfs', choices=['none', '202504', '202604', '202704'], default='none')
    args = parser.parse_args()
    manifest = json.loads((ROOT / 'manifest.json').read_text())
    for relative, expected in manifest['files'].items():
        data = (ROOT / relative).read_bytes()
        if SHA(data) != expected:
            raise ValueError('Input altered or mixed: ' + relative)
    args.out.mkdir(parents=True, exist_ok=False)
    report = dict(status='NOT_VALIDATED', genfs=args.genfs, policy_version=30, commands=[],
                  compiler_sha256=SHA(args.secilc.read_bytes()), checker_sha256=SHA(args.cap_checker.read_bytes()),
                  source_commit=manifest['compiler_source']['commit'], input_manifest_sha256=SHA((ROOT/'manifest.json').read_bytes()))
    caps = manifest['preserved_policycaps']
    succeeded = True
    for variant in ('original', 'candidate'):
        inputs = []
        for name in manifest['input_order']:
            path = ROOT / variant / name
            if not path.exists(): path = ROOT / 'original' / name
            inputs.append(path)
        if args.genfs != 'none':
            inputs.append(ROOT / 'original' / f'system_plat_sepolicy_genfs_{args.genfs}.cil')
        # This matches normal Android init: -N suppresses neverallow rechecking
        # at runtime. A second candidate build below checks those assertions.
        modes = ('init', 'neverallow-audit') if variant=='candidate' else ('init',)
        for mode in modes:
            binary = args.out / f'{variant}-{mode}.policy'
            contexts = args.out / f'{variant}-{mode}.file_contexts'
            command = [str(args.secilc.resolve()), '-m', '-M', 'true', '-G', '-c', '30']
            if mode == 'init': command.append('-N')
            command += ['-o', str(binary.resolve()), '-f', str(contexts.resolve())] + [str(p.resolve()) for p in inputs]
            result = subprocess.run(command, text=True, capture_output=True, timeout=180)
            log = args.out / f'{variant}-{mode}.log'
            log.write_text(result.stdout + result.stderr)
            record = dict(variant=variant, mode=mode, command=command, returncode=result.returncode)
            report['commands'].append(record)
            if variant == 'original':
                record['expected_namespace_failure'] = result.returncode != 0 and 'sysfs_battery_supply' in (result.stdout+result.stderr)
                succeeded &= record['expected_namespace_failure']
            elif result.returncode == 0:
                data = binary.read_bytes()
                magic, count = struct.unpack_from('<II', data)
                version = struct.unpack_from('<I', data, 8+count)[0]
                if magic != 0xf97cff8c or data[8:8+count] != b'SE Linux' or version != 30:
                    raise ValueError('Unexpected serialized policy header')
                record.update(bytes=len(data), sha256=SHA(data), serialized_version=version)
                checked = subprocess.run([str(args.cap_checker.resolve()), str(binary.resolve())]+caps,
                                         capture_output=True,text=True,timeout=30)
                (args.out / f'{variant}-{mode}-caps.log').write_text(checked.stdout+checked.stderr)
                record['caps_check_returncode'] = checked.returncode
                succeeded &= checked.returncode == 0
            else:
                succeeded = False
    report['status'] = 'HOST_COMPILE_AND_CAPS_VALIDATED_NOT_BOOT_TESTED' if succeeded else 'FAILED_OR_NEVERALLOW_FINDINGS'
    (args.out/'result.json').write_text(json.dumps(report, indent=2)+'\n')
    print(json.dumps(dict(status=report['status'], output=str(args.out)), indent=2))
    return 0 if succeeded else 1


if __name__ == '__main__': raise SystemExit(main())
